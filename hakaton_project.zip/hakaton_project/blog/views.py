from django.views.generic import ListView, DetailView
from django.shortcuts import redirect
from .models import Post, Comment

class BlogListView(ListView):
    model = Post
    template_name = "blog/list.html"
    context_object_name = "posts"
    ordering = ["-created_at"]

class BlogDetailView(DetailView):
    model = Post
    template_name = "blog/detail.html"
    context_object_name = "post"

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        if request.user.is_authenticated:
            text = request.POST.get("text")
            if text and text.strip():
                Comment.objects.create(post=self.object, user=request.user, text=text.strip())
        return redirect("blog-detail", pk=self.object.pk)