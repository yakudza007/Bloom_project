{#{% extends 'base.html' %}#}
{#{% block title %}Home - Bloom{% endblock %}#}
{#{% block content %}#}
{#{% load static %}#}
{##}
{#<!-- Hero -->#}
{#<section class="bg-gradient-to-r from-green-200 via-cyan-100 to-blue-200#}
{#                dark:from-gray-900 dark:via-gray-800 dark:to-gray-900#}
{#                text-gray-800 dark:text-gray-100 py-24 px-6 mb-20">#}
{#  <div class="max-w-4xl mx-auto text-center">#}
{#    <p class="text-lg mb-3 font-medium text-green-700 dark:text-green-300">Welcome to Bloom Project 🌱</p>#}
{#    <h1 class="text-5xl md:text-6xl font-extrabold leading-tight mb-6">#}
{#      Raise your helping hands <br />#}
{#      <span class="text-cyan-700 dark:text-cyan-300">to those who need</span>#}
{#    </h1>#}
{#    <p class="text-lg md:text-xl mb-8 text-gray-700 dark:text-gray-300">#}
{#      Let’s build a brighter future together — join meaningful projects and empower communities.#}
{#    </p>#}
{#    <a href="#projects" class="bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold shadow-lg">#}
{#      Explore Projects#}
{#    </a>#}
{#  </div>#}
{#</section>#}
{##}
{#<!-- 🌱 About Section -->#}
{#<section id="about"#}
{#  class="relative py-20 mb-20#}
{#         bg-gradient-to-br from-green-50 via-white to-cyan-50#}
{#         dark:from-gray-800 dark:via-gray-900 dark:to-gray-950">#}
{##}
{#  <div class="relative container mx-auto px-6 lg:px-12 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">#}
{##}
{#    <!-- Image -->#}
{#    <div class="flex justify-center">#}
{#      <img src="{% static 'media/about.jpg' %}" alt="About Bloom"#}
{#           class="rounded-2xl shadow-xl w-[520px] max-w-full object-cover#}
{#                  border-4 border-green-100 dark:border-gray-700"/>#}
{#    </div>#}
{##}
{#    <!-- Text -->#}
{#    <div>#}
{#      <p class="text-green-600 dark:text-green-400 font-semibold mb-2">🌿 About us</p>#}
{##}
{#      <h2 class="text-3xl md:text-4xl font-extrabold text-gray-800 dark:text-gray-100 mb-6">#}
{#        Empowering communities through meaningful change#}
{#      </h2>#}
{##}
{#      <p class="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">#}
{#        Bloom connects passionate people with impactful projects.#}
{#        From environmental initiatives to education,#}
{#        we believe in collective action to transform lives.#}
{#      </p>#}
{##}
{#      <!-- Bullets -->#}
{#      <ul class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-700 dark:text-gray-200 mb-8">#}
{#        <li>✅ Community-driven initiatives</li>#}
{#        <li>✅ Volunteer engagement</li>#}
{#        <li>✅ Transparency & accountability</li>#}
{#        <li>✅ Global changemakers</li>#}
{#        <li>✅ Sustainable focus</li>#}
{#        <li>✅ Innovative solutions</li>#}
{#      </ul>#}
{##}
{#      <!-- Quote -->#}
{#      <blockquote#}
{#        class="border-l-4 border-green-500 pl-4 italic#}
{#               text-gray-700 dark:text-gray-200#}
{#               bg-green-50 dark:bg-gray-800 p-4 rounded-lg shadow">#}
{#        "Together we thrive. Every small effort today will blossom into a brighter tomorrow."#}
{#      </blockquote>#}
{##}
{#      <p class="mt-3 font-semibold text-gray-800 dark:text-gray-100">#}
{#        Sarah Johnson <span class="text-sm text-gray-500 dark:text-gray-400">(CEO &amp; Founder)</span>#}
{#      </p>#}
{#    </div>#}
{#  </div>#}
{#</section>#}
{##}
{##}
{#<!-- 🌟 Trending Projects -->#}
{#<section id="projects"#}
{#  class="py-20 mb-20#}
{#         bg-gradient-to-b from-white via-green-50 to-cyan-50#}
{#         dark:from-gray-900 dark:via-gray-950 dark:to-black">#}
{##}
{#  <div class="text-center mb-12">#}
{#    <p class="text-green-600 dark:text-green-400 uppercase tracking-wider">Trending Causes</p>#}
{#    <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-100">#}
{#      🌍 Where help is most needed#}
{#    </h2>#}
{#  </div>#}
{##}
{#  <div class="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">#}
{#    {% for project in projects|slice:":3" %}#}
{#    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-md overflow-hidden#}
{#                hover:shadow-xl transition border border-green-100 dark:border-gray-700">#}
{##}
{#      <!-- Project image -->#}
{#      <div class="h-48 bg-gray-100 dark:bg-gray-700 flex items-center justify-center">#}
{#        {% if project.image %}#}
{#          <img src="{{ project.image.url }}" alt="{{ project.title }}"#}
{#               class="h-48 w-full object-cover">#}
{#        {% else %}#}
{#          <span class="text-gray-400 dark:text-gray-500">No image</span>#}
{#        {% endif %}#}
{#      </div>#}
{##}
{#      <!-- Card content -->#}
{#      <div class="p-5">#}
{#        <!-- Category badge -->#}
{#        <span class="inline-block px-3 py-1 text-xs rounded-full mb-3#}
{#          {% if project.category == 'health' %} bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300#}
{#          {% elif project.category == 'education' %} bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300#}
{#          {% elif project.category == 'environment' %} bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300#}
{#          {% else %} bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300 {% endif %}">#}
{#          {{ project.get_category_display }}#}
{#        </span>#}
{##}
{#        <!-- Title -->#}
{#        <h3 class="text-lg font-bold mb-2 text-gray-800 dark:text-gray-100">{{ project.title }}</h3>#}
{##}
{#        <!-- Description -->#}
{#        <p class="text-gray-600 dark:text-gray-300 text-sm mb-3">#}
{#          {{ project.description|truncatechars:60 }}#}
{#        </p>#}
{##}
{#        <!-- Goal + Progress -->#}
{#        <p class="text-sm text-gray-500 dark:text-gray-400 mb-2">#}
{#          Goal: ${{ project.goal_amount }} <br>#}
{#          Progress: {{ project.progress|floatformat:0 }}%#}
{#        </p>#}
{##}
{#        <!-- Progress bar -->#}
{#        <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-3">#}
{#          <div class="h-2 rounded-full#}
{#               {% if project.progress >= 100 %}bg-green-600 dark:bg-green-400#}
{#               {% else %}bg-cyan-500 dark:bg-cyan-400{% endif %}"#}
{#               style="width: {{ project.progress }}%">#}
{#          </div>#}
{#        </div>#}
{##}
{#        <!-- Button -->#}
{#        <a href="{% url 'project-detail' project.id %}"#}
{#           class="block w-full text-center py-2 rounded-lg#}
{#                  bg-green-600 text-white font-medium#}
{#                  hover:bg-green-700 transition#}
{#                  dark:bg-green-500 dark:hover:bg-green-600">#}
{#          View Details#}
{#        </a>#}
{#      </div>#}
{#    </div>#}
{#    {% endfor %}#}
{#  </div>#}
{#</section>#}
{##}
{#<!-- 💬 Community Discussions -->#}
{#<section class="py-20 mb-20#}
{#                bg-gradient-to-b from-cyan-50 to-green-50#}
{#                dark:from-gray-900 dark:via-gray-950 dark:to-black">#}
{#  <div class="text-center mb-12">#}
{#    <p class="text-cyan-600 dark:text-cyan-400 uppercase tracking-wider">#}
{#      Community Discussions#}
{#    </p>#}
{#    <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-100">#}
{#      💬 Join the conversation#}
{#    </h2>#}
{#  </div>#}
{##}
{#  <div class="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">#}
{#    {% for g in groups|slice:":3" %}#}
{#    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md#}
{#                overflow-hidden hover:shadow-lg transition#}
{#                border border-cyan-100 dark:border-gray-700#}
{#                flex flex-col">#}
{##}
{#      <!-- Group header -->#}
{#      <div class="bg-gradient-to-r from-green-400 to-cyan-500#}
{#                  dark:from-green-600 dark:to-cyan-700#}
{#                  p-4 text-white">#}
{#        <h3 class="font-semibold text-lg">{{ g.name }}</h3>#}
{#      </div>#}
{##}
{#      <!-- Messages -->#}
{#      <div class="p-5 flex-1 space-y-3">#}
{#        {% for m in g.latest_messages %}#}
{#          <div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 text-sm">#}
{#            <p class="font-semibold text-green-600 dark:text-green-400">#}
{#              {% if m.user %}{{ m.user.username }}{% else %}Anonymous{% endif %}#}
{#            </p>#}
{#            <p class="text-gray-700 dark:text-gray-300">#}
{#              {{ m.text|truncatechars:80 }}#}
{#            </p>#}
{#          </div>#}
{#        {% empty %}#}
{#          <p class="text-gray-400 dark:text-gray-500 italic text-center">#}
{#            No messages yet#}
{#          </p>#}
{#        {% endfor %}#}
{#      </div>#}
{##}
{#      <!-- Join button -->#}
{#      <a href="{% url 'groups' %}?group={{ g.id }}"#}
{#         class="block w-full text-center py-2 rounded-b-lg#}
{#                bg-green-600 text-white font-medium hover:bg-green-700#}
{#                dark:bg-green-500 dark:hover:bg-green-600 transition">#}
{#        Join Discussion →#}
{#      </a>#}
{#    </div>#}
{#    {% empty %}#}
{#    <div class="col-span-3 text-center py-8 text-gray-500 dark:text-gray-400">#}
{#      <i class="fa-solid fa-comments text-4xl mb-4 block"></i>#}
{#      <p>No discussion groups yet</p>#}
{#    </div>#}
{#    {% endfor %}#}
{#  </div>#}
{#</section>#}
{##}
{#{% endblock %}#}

{#{% extends 'base.html' %}#}
{#{% block title %}Home - Bloom{% endblock %}#}
{#{% block content %}#}
{#{% load static %}#}
{##}
{#<!-- Hero -->#}
{#<section class="bg-gradient-to-r from-green-200 via-cyan-100 to-blue-200#}
{#                dark:from-gray-900 dark:via-gray-800 dark:to-gray-900#}
{#                text-gray-800 dark:text-gray-100 py-20 md:py-24 px-6">#}
{#  <div class="max-w-4xl mx-auto text-center">#}
{#    <p class="text-lg mb-3 font-medium text-green-700 dark:text-green-300">Welcome to Bloom Project 🌱</p>#}
{#    <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-6">#}
{#      Raise your helping hands <br />#}
{#      <span class="text-cyan-700 dark:text-cyan-300">to those who need</span>#}
{#    </h1>#}
{#    <p class="text-lg md:text-xl mb-8 text-gray-700 dark:text-gray-300">#}
{#      Let's build a brighter future together — join meaningful projects and empower communities.#}
{#    </p>#}
{#    <a href="#projects" class="inline-block bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold shadow-lg transition-colors">#}
{#      Explore Projects#}
{#    </a>#}
{#  </div>#}
{#</section>#}
{##}
{#<!-- 🌱 About Section -->#}
{#<section id="about"#}
{#  class="relative py-16 md:py-20#}
{#         bg-gradient-to-br from-green-50 via-white to-cyan-50#}
{#         dark:from-gray-800 dark:via-gray-900 dark:to-gray-950">#}
{##}
{#  <div class="relative container mx-auto px-6 lg:px-12 grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-12 items-center">#}
{##}
{#    <!-- Image -->#}
{#    <div class="flex justify-center order-2 md:order-1">#}
{#      <img src="{% static 'media/about.jpg' %}" alt="About Bloom"#}
{#           class="rounded-2xl shadow-xl w-full max-w-md object-cover#}
{#                  border-4 border-green-100 dark:border-gray-700"/>#}
{#    </div>#}
{##}
{#    <!-- Text -->#}
{#    <div class="order-1 md:order-2">#}
{#      <p class="text-green-600 dark:text-green-400 font-semibold mb-2">🌿 About us</p>#}
{##}
{#      <h2 class="text-3xl md:text-4xl font-extrabold text-gray-800 dark:text-gray-100 mb-6">#}
{#        Empowering communities through meaningful change#}
{#      </h2>#}
{##}
{#      <p class="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">#}
{#        Bloom connects passionate people with impactful projects.#}
{#        From environmental initiatives to education,#}
{#        we believe in collective action to transform lives.#}
{#      </p>#}
{##}
{#      <!-- Bullets -->#}
{#      <ul class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-700 dark:text-gray-200 mb-8">#}
{#        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Community-driven initiatives</li>#}
{#        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Volunteer engagement</li>#}
{#        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Transparency & accountability</li>#}
{#        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Global changemakers</li>#}
{#        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Sustainable focus</li>#}
{#        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Innovative solutions</li>#}
{#      </ul>#}
{##}
{#      <!-- Quote -->#}
{#      <blockquote#}
{#        class="border-l-4 border-green-500 pl-4 italic#}
{#               text-gray-700 dark:text-gray-200#}
{#               bg-green-50 dark:bg-gray-800 p-4 rounded-lg shadow-sm">#}
{#        "Together we thrive. Every small effort today will blossom into a brighter tomorrow."#}
{#        <p class="mt-3 font-semibold text-gray-800 dark:text-gray-100 not-italic">#}
{#          Sarah Johnson <span class="text-sm text-gray-500 dark:text-gray-400">(CEO &amp; Founder)</span>#}
{#        </p>#}
{#      </blockquote>#}
{#    </div>#}
{#  </div>#}
{#</section>#}
{##}
{#<!-- 🌟 Trending Projects -->#}
{#<section id="projects"#}
{#  class="py-16 md:py-20#}
{#         bg-gradient-to-b from-white via-green-50 to-cyan-50#}
{#         dark:from-gray-900 dark:via-gray-950 dark:to-black">#}
{##}
{#  <div class="container mx-auto px-6">#}
{#    <div class="text-center mb-12">#}
{#      <p class="text-green-600 dark:text-green-400 uppercase tracking-wider text-sm font-medium">Trending Causes</p>#}
{#      <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-100 mt-2">#}
{#        🌍 Where help is most needed#}
{#      </h2>#}
{#    </div>#}
{##}
{#    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">#}
{#      {% for project in projects|slice:":3" %}#}
{#      <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-md overflow-hidden#}
{#                  hover:shadow-xl transition-all duration-300 border border-green-100 dark:border-gray-700">#}
{##}
{#        <!-- Project image -->#}
{#        <div class="h-48 bg-gray-100 dark:bg-gray-700 flex items-center justify-center overflow-hidden">#}
{#          {% if project.image %}#}
{#            <img src="{{ project.image.url }}" alt="{{ project.title }}"#}
{#                 class="h-48 w-full object-cover transition-transform duration-500 hover:scale-105">#}
{#          {% else %}#}
{#            <span class="text-gray-400 dark:text-gray-500">No image</span>#}
{#          {% endif %}#}
{#        </div>#}
{##}
{#        <!-- Card content -->#}
{#        <div class="p-5">#}
{#          <!-- Category badge -->#}
{#          <span class="inline-block px-3 py-1 text-xs rounded-full mb-3#}
{#            {% if project.category == 'health' %} bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300#}
{#            {% elif project.category == 'education' %} bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300#}
{#            {% elif project.category == 'environment' %} bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300#}
{#            {% else %} bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300 {% endif %}">#}
{#            {{ project.get_category_display }}#}
{#          </span>#}
{##}
{#          <!-- Title -->#}
{#          <h3 class="text-lg font-bold mb-2 text-gray-800 dark:text-gray-100">{{ project.title }}</h3>#}
{##}
{#          <!-- Description -->#}
{#          <p class="text-gray-600 dark:text-gray-300 text-sm mb-3">#}
{#            {{ project.description|truncatechars:60 }}#}
{#          </p>#}
{##}
{#          <!-- Goal + Progress -->#}
{#          <p class="text-sm text-gray-500 dark:text-gray-400 mb-2">#}
{#            Goal: ${{ project.goal_amount }} <br>#}
{#            Progress: {{ project.progress|floatformat:0 }}%#}
{#          </p>#}
{##}
{#          <!-- Progress bar -->#}
{#          <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-4">#}
{#            <div class="h-2 rounded-full#}
{#                 {% if project.progress >= 100 %}bg-green-600 dark:bg-green-400#}
{#                 {% else %}bg-cyan-500 dark:bg-cyan-400{% endif %}"#}
{#                 style="width: {{ project.progress }}%">#}
{#            </div>#}
{#          </div>#}
{##}
{#          <!-- Button -->#}
{#          <a href="{% url 'project-detail' project.id %}"#}
{#             class="block w-full text-center py-2 rounded-lg#}
{#                    bg-green-600 text-white font-medium#}
{#                    hover:bg-green-700 transition#}
{#                    dark:bg-green-500 dark:hover:bg-green-600">#}
{#            View Details#}
{#          </a>#}
{#        </div>#}
{#      </div>#}
{#      {% endfor %}#}
{#    </div>#}
{#  </div>#}
{#</section>#}
{##}
{#<!-- 💬 Community Discussions -->#}
{#<section class="py-16 md:py-20#}
{#                bg-gradient-to-b from-cyan-50 to-green-50#}
{#                dark:from-gray-900 dark:via-gray-950 dark:to-black">#}
{#  <div class="container mx-auto px-6">#}
{#    <div class="text-center mb-12">#}
{#      <p class="text-cyan-600 dark:text-cyan-400 uppercase tracking-wider text-sm font-medium">#}
{#        Community Discussions#}
{#      </p>#}
{#      <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-100 mt-2">#}
{#        💬 Join the conversation#}
{#      </h2>#}
{#    </div>#}
{##}
{#    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">#}
{#      {% for g in groups|slice:":3" %}#}
{#      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md#}
{#                  overflow-hidden hover:shadow-lg transition-all duration-300#}
{#                  border border-cyan-100 dark:border-gray-700#}
{#                  flex flex-col h-full">#}
{##}
{#        <!-- Group header -->#}
{#        <div class="bg-gradient-to-r from-green-400 to-cyan-500#}
{#                    dark:from-green-600 dark:to-cyan-700#}
{#                    p-4 text-white">#}
{#          <h3 class="font-semibold text-lg">{{ g.name }}</h3>#}
{#        </div>#}
{##}
{#        <!-- Messages -->#}
{#        <div class="p-5 flex-1 space-y-3">#}
{#          {% for m in g.latest_messages %}#}
{#            <div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 text-sm">#}
{#              <p class="font-semibold text-green-600 dark:text-green-400 mb-1">#}
{#                {% if m.user %}{{ m.user.username }}{% else %}Anonymous{% endif %}#}
{#              </p>#}
{#              <p class="text-gray-700 dark:text-gray-300">#}
{#                {{ m.text|truncatechars:80 }}#}
{#              </p>#}
{#            </div>#}
{#          {% empty %}#}
{#            <div class="text-center py-4 text-gray-400 dark:text-gray-500 italic">#}
{#              <i class="fa-solid fa-comment-slash text-2xl mb-2 block"></i>#}
{#              <p>No messages yet</p>#}
{#            </div>#}
{#          {% endfor %}#}
{#        </div>#}
{##}
{#        <!-- Join button -->#}
{#        <a href="{% url 'groups' %}?group={{ g.id }}"#}
{#           class="block w-full text-center py-3 rounded-b-xl#}
{#                  bg-green-600 text-white font-medium hover:bg-green-700#}
{#                  dark:bg-green-500 dark:hover:bg-green-600 transition-colors mt-auto">#}
{#          Join Discussion →#}
{#        </a>#}
{#      </div>#}
{#      {% empty %}#}
{#      <div class="col-span-3 text-center py-8 text-gray-500 dark:text-gray-400">#}
{#        <i class="fa-solid fa-comments text-4xl mb-4 block"></i>#}
{#        <p>No discussion groups yet</p>#}
{#      </div>#}
{#      {% endfor %}#}
{#    </div>#}
{#  </div>#}
{#</section>#}
{##}
{#{% endblock %}#}